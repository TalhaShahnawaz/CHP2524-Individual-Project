<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Hello')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div id="wrapper">

        <ul class="navbar-nav bg-gradient-dark sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="/adminProfile">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Admin Panel</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Pages Collapse Menu -->

             <li class="nav-item">                  
                <a class="nav-link" href="<?php echo e(url('/')); ?>">
                    <i class="fas fa-fw fa-folder"></i>
                    <span>Home</span>
                </a>
            </li>
            <li class="nav-item">                  
                <a class="nav-link" href="<?php echo e(url('/mentalwellbeingdata')); ?>">
                    <i class="fas fa-fw fa-folder"></i>
                    <span>Mental Wellbeing</span>
                </a>
            </li>
            <li class="nav-item">                  
                <a class="nav-link" href="<?php echo e(url('/reguser')); ?>">
                    <i class="fas fa-fw fa-folder"></i>
                    <span>All Users</span>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link"  href="/approvedpatient">
                <i class="fas fa-fw fa-chart-area"></i>
                    <span>Approved Patients</span>
                </a>
                
            </li>

            <!-- Nav Item - Charts -->
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(url('/approveddonors')); ?>">
                    <i class="fas fa-fw fa-chart-area"></i>
                    <span>Approved Donors</span></a>
            </li>

            
            

            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(url('subscription')); ?>">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Contact Request</span></a>
            </li>

            
            <li class="nav-item">                  
                <a class="nav-link" href="<?php echo e(url('/patientShow')); ?>">
                    <i class="fas fa-fw fa-folder"></i>
                    <span>Patient Requests</span>
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link collapsed" data-toggle="collapse" data-target="#collapseFour"
                aria-expanded="true" aria-controls="collapseFour" href="#">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Donation Request</span>
                </a>
                <div id="collapseFour" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="<?php echo e(url('foodShow')); ?>">Food Donation</a>
                        <a class="collapse-item" href="<?php echo e(url('bloodShow')); ?>">Blood Donation</a>
                        
                        <a class="collapse-item" href="<?php echo e(url('clothShow')); ?>">Cloth Donation</a>
                       
                        <a class="collapse-item" href="<?php echo e(url('financialShow')); ?>">Financial Donation</a>
                    </div>
                </div>
            </li>

            

            
            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
        </ul>
        <!-- End of Sidebar -->
        <div class="col-md-10">
            <h3>Website Subscription</h3>
            <table class="table table-light table-hover text-center">
                <thead class="table-dark">
                    <tr>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>E-mail</th>
                        <th>Subscription Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $subs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="border-bottom-primary"><?php echo e($sub->subFirst); ?></td>
                        <td class="border-bottom-primary"><?php echo e($sub->subLast); ?></td>
                        <td class="border-bottom-primary"><?php echo e($sub->subEmail); ?></td>
                        <td class="border-bottom-primary"><?php echo e($sub->created_at); ?></td>
                        <td class="border-bottom-primary">
                            <a href="#" class="btn btn-info btn-sm">Sent Mail</a>
                            <a href="<?php echo e(url('/destroy', $sub->id)); ?>" class="btn btn-danger btn-sm">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php if(session()->has('mge')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('mge')); ?>

            </div>                    
        <?php endif; ?>
        </div>

        <!-- Content Wrapper -->

        <div id="content-wrapper" class="d-flex flex-column ml-5">
            
    </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\aizaz\Downloads\Web Proj\CHP2524-Individual-Project\Donation-Talha\resources\views/admin/subscription.blade.php ENDPATH**/ ?>