<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="/css/app.css">
    <link rel="shortcut icon" type="image/x-icon" href="/img/favicon.png">
    <!-- Place favicon.ico in the root directory -->

    <!-- CSS here -->
    <link rel="stylesheet" href="/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/owl.carousel.min.css">
    <link rel="stylesheet" href="/css/magnific-popup.css">
    <link rel="stylesheet" href="/css/font-awesome.min.css">
    <link rel="stylesheet" href="/css/themify-icons.css">
    <link rel="stylesheet" href="/css/nice-select.css">
    <link rel="stylesheet" href="/css/flaticon.css">
    <link rel="stylesheet" href="/css/gijgo.css">
    <link rel="stylesheet" href="/css/animate.css">
    <link rel="stylesheet" href="/css/slicknav.css">
    <link rel="stylesheet" href="/css/style.css">
    <!-- Styles -->
    <style>
        
      * {
        box-sizing: border-box;
      }
      
      .container {
        max-width: 800px;
        margin: 0 auto;
        padding: 20px;
      }
      h1 {
        text-align: center;
      }
      form {
        background-color: #f2f2f2;
        padding: 20px;
        border-radius: 10px;
      }
      label {
        display: block;
        font-weight: bold;
        margin-bottom: 10px;
      }
      input[type="text"],
      textarea {
        width: 100%;
        padding: 10px;
        border: none;
        border-radius: 5px;
        margin-bottom: 20px;
      }
      textarea {
        resize: none;
        height: 150px;
      }
      select {
        width: 100%;
        padding: 10px;
        border: none;
        border-radius: 5px;
        margin-bottom: 20px;
      }
      input[type="submit"] {
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
      }
      input[type="submit"]:hover {
        background-color: #3e8e41;
      }
      .error-message {
        color: red;
        font-size: 0.8rem;
        margin-top: 5px;
      }
    
        body {
            font-family: 'Nunito', sans-serif;
        }

    </style>
</head>

<body>
    

    <header>
         
        <div class="header-area ">
            <div class="header-top_area">
                <div class="container-fluid">
                    <div class="row">
                        
                </div>
            </div>
        </div>
        <div id="sticky-header" class="main-header-area">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-xl-3 col-lg-3">
                        <div class="logo">
                            <a href="<?php echo e(url('/')); ?>">
                                <img src="img/logo.png" alt="">
                            </a>
                        </div>
                    </div>
                    <div class="col-xl-9 col-lg-9">
                        <div class="main-menu">
                            <nav>
                                <ul id="navigation">
                                    <li><a href="/">Home</a></li>
                                    
                                    <?php if(Route::has('login')): ?>
                                    <?php if(auth()->guard()->check()): ?>
                                    <!-- Only show the "Donations" tab if the user is logged in as a donor -->
                                    <?php if(Auth::check() && (Auth::user()->role_id == 'user' || Auth::user()->role_id == 'admin')): ?>
                                    <li><a href="#">Donations<i class="ti-angle-down"></i></a>
                                        <ul class="submenu">
                                            <li><a class="dropdown-item" href="<?php echo e(url('food')); ?>">Food Donation</a></li>
                                            <li><a class="dropdown-item" href="<?php echo e(url('blood')); ?>">Blood Donation</a></li>
                                            <li><a class="dropdown-item" href="<?php echo e(url('clothing')); ?>">Cloth Donation</a></li>
                                            <li><a class="dropdown-item" href="<?php echo e(url('financial')); ?>">Financial Donation</a></li>
                                        </ul>
                                    </li>
                                    <?php else: ?>
                                    <li><a href="/patient">Patients</a></li>
                                    <?php endif; ?>
                                    <?php else: ?>
                                    <li><a href="#">Donations<i class="ti-angle-down"></i></a>
                                        <ul class="submenu">
                                            <li><a class="dropdown-item" href="<?php echo e(url('food')); ?>">Food Donation</a></li>
                                            <li><a class="dropdown-item" href="<?php echo e(url('blood')); ?>">Blood Donation</a></li>
                                            <li><a class="dropdown-item" href="<?php echo e(url('clothing')); ?>">Cloth Donation</a></li>
                                            <li><a class="dropdown-item" href="<?php echo e(url('financial')); ?>">Financial Donation</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="/patient">Patients</a></li>
                                    <?php endif; ?>
                                    <?php endif; ?>




                                    
                                    
                                    <li><a href="<?php echo e(url('mentalwellbeing')); ?>">Mental Well-Being</a></li>
                                    <li><a href="/about">About</a></li>
                                    <!-- -->
                                    <?php if(Route::has('login')): ?>
                                
                                    <?php if(auth()->guard()->check()): ?>
                                    
                                    <?php if(Auth::check() && Auth::user()->role_id == 'admin'): ?>

                                    <li style="background-color: white;" ><a href="<?php echo e(url('/adminProfile')); ?>" style="color: black;">Dashboard</a></li>
                                    <?php endif; ?>
                                    <li style="background-color: white;"  <form action="<?php echo e(url('/logout')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="logout-btn">Logout</button>
                                </form>    </li>    <?php else: ?>
                            <li style="background-color: white;" > <a href="<?php echo e(route('login')); ?>" style="color: black;">Log in</a></li>

                                    <?php if(Route::has('register')): ?>
                                    <li style="background-color: white;">
                                        <a href="<?php echo e(route('register')); ?>" style="color: black;">Register</a>
                                        </li>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                
                                <?php endif; ?>
        <!-- -->
                                </ul>
                            </nav>
                            <div class="Appointment">
                                <div class="book_btn d-none d-lg-block">
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="mobile_menu d-block d-lg-none"></div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </header>


    <div class="slider_area">
        <div class="single_slider  d-flex align-items-center slider_make_1">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9">
                        <div class="slider_text ">
                            <span>Get Started Now!</span>
                            <h3>Having Mental or Physiological Issues?  <br>We can Help</p>
                            
                            <a href="/about" class="boxed-btn3">Learn More
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

    
    
        
    <main>


    <div class="container">
    <div class="section_title text-center mb-55">
                        <h3><span>Please Fill this Form</span></h3>
                    </div>
                    <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
                    <form action="<?php echo e(route('form.submit')); ?>" method="POST">
  <?php echo csrf_field(); ?>
  <div class="form-group">
    <label for="name">Name</label>
    <input type="text" class="form-control" id="name" name="name" placeholder="Enter your name">
  </div>
  <div class="form-group">
    <label for="email">Email address</label>
    <input type="email" class="form-control" id="email" name="email" placeholder="Enter email">
  </div>
  <div class="form-group">
    <label for="mobile">Mobile Number</label>
    <input type="number" class="form-control" id="mobile" name="mobile" placeholder="Enter your mobile number">
  </div>
  <div class="form-group">
    <label for="emergency_mobile">Emergency Mobile Number</label>
    <input type="number" class="form-control" id="emergency_mobile" name="emergency_mobile" placeholder="Enter emergency mobile number">
  </div>
  <div class="form-group">
    <label for="current_location">Current Location</label>
    <input type="text" class="form-control" id="current_location" name="current_location" placeholder="Enter your current location">
  </div>
  <div class="form-group">
    <label for="message">Message</label>
    <textarea class="form-control" id="message" name="message" placeholder="Enter your message"></textarea>
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
                    </div>
 
<div class="container">

                    <section class="help">
    <h2>How We Can Help</h2>
    <p class="help-text">Our team of mental health professionals is dedicated to helping you improve your mental well-being. We offer a range of services, including:</p>
    <ul class="help-list">
      <li>Counseling</li>
      <li>Therapy</li>
      <li>Support groups</li>
    </ul>
    <p class="help-contact">Contact us today to learn more about how we can help you.</p>
</section>
<section class="help">
    <h2>What You Can Expect</h2>
    <p class="expect-text">When you come to us for help with your mental well-being, you can expect:</p>
    <ul class="expect-list">
      <li>A safe and confidential environment</li>
      <li>Professional and caring staff</li>
      <li>Individualized treatment plans</li>
      <li>Support and resources for your loved ones</li>
    </ul>
    <p class="expect-goal">We believe that everyone deserves to live a happy and fulfilling life, and we are committed to helping you achieve that goal.</p>
</section>
      
    </main>
    </div>
    
    <section class="tips">
  <div class="tips__content">
    <h2>Important tips about mental health.</h2>
    <ul class="tips__list">
      <li>
        <div class="tips__box">
          <img class="tips__image" src="img/daily-routines-and-habits.png" alt="Internet for all devices image">
          <div class="tips__caption">
            <h3>Have a routine.</h3>
          </div>
        </div>
      </li>

      <li>
        <div class="tips__box">
          <img class="tips__image" src="img/computational-social.png" alt="Boost your productivity image">
          <div class="tips__caption">
            <h3>Social contact is important.</h3>
          </div>
        </div>
      </li>

      <li>
        <div class="tips__box">
          <img class="tips__image" src="img/keep-moving.jpg" alt="Pay as You Go image">
          <div class="tips__caption">
            <h3>Keep moving.</h3>
          </div>
        </div>
      </li>

      

      <li>
        <div class="tips__box">
          <img class="tips__image" src="img/eat-health-food.jpg" alt="Pay as You Go image">
          <div class="tips__caption">
            <h3>Eat Healthy Food.</h3>
          </div>
        </div>
      </li>  
    </ul>
  </div>
</section>


</div>

    <footer class="footer bg-green-300">
        <div class="footer_top">
            <div class="container">
                <div class="row">
                    <div class="col-xl-4 col-md-6 col-lg-4 ">
                        <div class="footer_widget">
                            <div class="footer_logo">
                                <a href="#">
                                    <img src="img/footer_logo.png" alt="">
                                </a>
                            </div>
                            <p class="address_text">Lorem ipsum dolor sit amet, <br> consectetur adipiscing elit, sed do
                                <br> eiusmod tempor incididunt ut labore.
                            </p>
                            <div class="socail_links">
                                <ul>
                                    <li>
                                        <a href="#">
                                            <i class="ti-facebook"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <i class="ti-twitter-alt"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <i class="fa fa-dribbble"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <i class="fa fa-instagram"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>

                        </div>
                    </div>
                    <div class="col-xl-2 col-md-6 col-lg-2">
                        <div class="footer_widget">
                            <h3 class="footer_title">
                                Services
                            </h3>
                            <ul class="links">
                                <li><a href="#">Donate</a></li>
                                <li><a href="#">Sponsor</a></li>
                                <li><a href="#">Fundraise</a></li>
                                
                            </ul>
                        </div>
                    </div>
                  
                    <div class="col-xl-3 col-md-6 col-lg-3">
                        <div class="footer_widget">
                            <h3 class="footer_title">
                                Top News
                            </h3>
                            <ul class="news_links">
                                <li>
                                    <div class="thumb">
                                        <a href="#">
                                            <img src="img/news/news_1.png" alt="">
                                        </a>
                                    </div>
                                    <div class="info">
                                        <a href="#">
                                            <h4>School for African
                                                Childrens</h4>
                                        </a>
                                        <span>Jun 12, 2019</span>
                                    </div>
                                </li>
                                <li>
                                    <div class="thumb">
                                        <a href="#">
                                            <img src="img/news/news_2.png" alt="">
                                        </a>
                                    </div>
                                    <div class="info">
                                        <a href="#">
                                            <h4>School for African
                                                Childrens</h4>
                                        </a>
                                        <span>Jun 12, 2019</span>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copy-right_text">
            <div class="container">
                <div class="row">
                    <div class="bordered_1px "></div>
                    <div class="col-xl-12">
                        <p class="copy_right text-center">
                            <p class="text-center ">
                                Copyright &copy; 
                                <script>
                                    document.write(new Date().getFullYear());
                                </script>
                                    
                            </p>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <?php /**PATH C:\Users\aizaz\Downloads\Web Proj\CHP2524-Individual-Project\Donation-Talha\resources\views/mentalwellbeing1.blade.php ENDPATH**/ ?>